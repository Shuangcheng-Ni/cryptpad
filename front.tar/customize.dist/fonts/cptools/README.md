The "cptools" font is using the [palette-solid icon](https://fontawesome.com/icons/palette?style=solid) from the "Font Awesome 5 Free" icon set.

This icon is licensed under the [Creative Commons Attribution 4.0 International license](https://fontawesome.com/license/free).
